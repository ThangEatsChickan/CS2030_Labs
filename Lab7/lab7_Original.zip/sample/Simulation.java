/**
 * The Simulation class encapsulates information pertaining to our
 * Simulation.
 *
 * @author atharvjoshi
 * @author weitsang
 * @version CS2030 AY19/20 Sem 1 Lab 7
 */
public class Simulation {
  /** The time a server takes to serve a customer. */
  static final double SERVICE_TIME = 1.0;
}
