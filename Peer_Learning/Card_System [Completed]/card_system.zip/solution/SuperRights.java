interface SuperRights extends BasicRights {
    public Customer rewardEventBonus(Customer cust, double prize);
}
