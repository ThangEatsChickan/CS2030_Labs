interface BasicRights {
    public Card checkBalance();
    public User doTopUp(double value);
}
